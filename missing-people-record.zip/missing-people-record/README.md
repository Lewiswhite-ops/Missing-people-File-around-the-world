# Missing people record

A Pen created on CodePen.

Original URL: [https://codepen.io/Lewis-White/pen/RNWpRMY](https://codepen.io/Lewis-White/pen/RNWpRMY).

its a site for people who wanna know about the missing people news
