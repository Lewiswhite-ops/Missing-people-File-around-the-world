const people = [
  // 7 Missing
  {
    name: "Samantha Collins",
    status: "missing",
    missingDate: "2019-11-05",
    lastSeen: "London, UK",
    description: `Samantha was last seen walking home from a friend's party. She was wearing a red jacket and carrying a black backpack. 
    She disappeared mysteriously, with no phone activity afterwards. Her family believes she may have been abducted. 
    Police searched the nearby woods but found no trace.`,
  },
  {
    name: "Jacob Martinez",
    status: "missing",
    missingDate: "2020-06-12",
    lastSeen: "Los Angeles, CA, USA",
    description: `Jacob was jogging in Griffith Park when he vanished. He was wearing blue running shorts and a grey t-shirt. 
    Witnesses say he looked distracted but there was no sign of struggle. His phone last pinged near the park entrance. 
    Extensive searches yielded no clues.`,
  },
  {
    name: "Emily Nguyen",
    status: "missing",
    missingDate: "2018-02-20",
    lastSeen: "Sydney, Australia",
    description: `Emily left her home to attend university classes but never arrived. She was carrying a laptop and textbooks. 
    CCTV footage shows her boarding a bus but disappears afterwards. There are theories about voluntary disappearance, 
    but her family insists she would never leave without notice.`,
  },
  {
    name: "Mohamed Hassan",
    status: "missing",
    missingDate: "2021-08-30",
    lastSeen: "Cairo, Egypt",
    description: `Mohamed was last seen near Tahrir Square attending a protest. He was wearing glasses and a blue shirt. 
    Witnesses say he was detained by security forces, and his whereabouts have been unknown since. 
    Human rights organizations have raised concerns.`,
  },
  {
    name: "Aisha Johnson",
    status: "missing",
    missingDate: "2017-12-15",
    lastSeen: "Chicago, IL, USA",
    description: `Aisha went out for groceries and never returned. She wore a green coat and carried a small handbag. 
    Her phone was turned off after she left. Neighbors reported suspicious activity in the area days later.`,
  },
  {
    name: "Liam O'Connor",
    status: "missing",
    missingDate: "2022-04-18",
    lastSeen: "Dublin, Ireland",
    description: `Liam was last seen leaving a pub late at night. He was known to suffer from anxiety but had no history of disappearing. 
    His wallet and phone were found on a nearby bench. Friends worry about foul play.`,
  },
  {
    name: "Yuki Tanaka",
    status: "missing",
    missingDate: "2020-09-25",
    lastSeen: "Tokyo, Japan",
    description: `Yuki was on her way home from work when she vanished. She was wearing a navy coat and carrying a briefcase. 
    Surveillance cameras caught her entering a subway station but no footage of her leaving.`,
  },

  // 7 Found
  {
    name: "Daniel Reed",
    status: "found",
    missingDate: "2016-05-10",
    foundDate: "2016-06-02",
    lastSeen: "Boston, MA, USA",
    foundLocation: "Cambridge, MA, USA",
    description: `Daniel disappeared after leaving work one day. He was found almost a month later, disoriented but safe, 
    near a park in Cambridge. He was suffering from amnesia and could not explain his absence. After treatment, he returned to his family.`,
  },
  {
    name: "Sophia Alvarez",
    status: "found",
    missingDate: "2018-07-22",
    foundDate: "2018-08-05",
    lastSeen: "Mexico City, Mexico",
    foundLocation: "Puebla, Mexico",
    description: `Sophia vanished during a family trip. She was located two weeks later in a small town nearby, 
    confused and unable to recall events. Authorities believe she suffered a head injury. She has since recovered.`,
  },
  {
    name: "Michael Thompson",
    status: "found",
    missingDate: "2019-10-01",
    foundDate: "2019-10-15",
    lastSeen: "Seattle, WA, USA",
    foundLocation: "Vancouver, BC, Canada",
    description: `Michael went missing after attending a concert. Two weeks later, he was found in Vancouver, 
    suffering from hypothermia. He explained he got lost trying to find his hotel and was unable to call for help.`,
  },
  {
    name: "Olivia Petrova",
    status: "found",
    missingDate: "2017-03-19",
    foundDate: "2017-04-01",
    lastSeen: "Moscow, Russia",
    foundLocation: "Saint Petersburg, Russia",
    description: `Olivia disappeared after a late-night work meeting. She was found nearly two weeks later in Saint Petersburg, 
    confused but physically unharmed. She was reportedly the victim of a robbery and kidnapping.`,
  },
  {
    name: "David Kim",
    status: "found",
    missingDate: "2021-12-11",
    foundDate: "2022-01-05",
    lastSeen: "Seoul, South Korea",
    foundLocation: "Busan, South Korea",
    description: `David left home for a short trip but did not arrive at his destination. Authorities found him in Busan, 
    suffering from dehydration but otherwise healthy. He was unable to provide details of his disappearance.`,
  },
  {
    name: "Maya Singh",
    status: "found",
    missingDate: "2020-01-07",
    foundDate: "2020-01-30",
    lastSeen: "Delhi, India",
    foundLocation: "Jaipur, India",
    description: `Maya disappeared after a family dispute. She was found three weeks later in Jaipur, 
    safe but emotionally distressed. She has since reunited with her family.`,
  },
  {
    name: "Carlos Mendes",
    status: "found",
    missingDate: "2015-09-14",
    foundDate: "2015-10-02",
    lastSeen: "Lisbon, Portugal",
    foundLocation: "Porto, Portugal",
    description: `Carlos vanished after a night out with friends. He was found in Porto after being hospitalized for exhaustion. 
    He recalls losing his wallet and phone and being unable to contact anyone.`,
  }
];

// Container element
const container = document.getElementById('peopleContainer');
const buttons = document.querySelectorAll('.filter-btn');

// Function to create person box HTML
function createPersonBox(person) {
  const box = document.createElement('div');
  box.className = 'person-box';
  box.dataset.status = person.status;

  let html = `<h3>${person.name}</h3>`;
  html += `<p><strong>Status:</strong> ${person.status === 'missing' ? 'Missing' : 'Found'}</p>`;
  html += `<p><strong>Last Seen Location:</strong> ${person.lastSeen}</p>`;
  html += `<p><strong>Missing Since:</strong> ${person.missingDate}</p>`;

  if (person.status === 'found') {
    html += `<p><strong>Found Location:</strong> ${person.foundLocation}</p>`;
    html += `<p><strong>Found Date:</strong> ${person.foundDate}</p>`;
  }

  html += `<p><strong>Description:</strong> ${person.description}</p>`;

  box.innerHTML = html;
  return box;
}

// Render all people initially
function renderPeople(filter = 'all') {
  container.innerHTML = '';
  let filteredPeople = people;

  if (filter === 'missing') {
    filteredPeople = people.filter(p => p.status === 'missing');
  } else if (filter === 'found') {
    filteredPeople = people.filter(p => p.status === 'found');
  }

  filteredPeople.forEach(person => {
    const box = createPersonBox(person);
    container.appendChild(box);
  });
}

// Button click event handler
buttons.forEach(button => {
  button.addEventListener('click', () => {
    // Remove active class from all buttons
    buttons.forEach(btn => btn.classList.remove('active'));
    // Add active class to clicked button
    button.classList.add('active');

    // Render filtered people
    renderPeople(button.dataset.filter);
  });
});

// Initial render (show all)
renderPeople();
